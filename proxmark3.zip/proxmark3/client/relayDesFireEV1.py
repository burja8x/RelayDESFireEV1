from subprocess import PIPE, Popen
import time


print("Hello")
tryX = 0
emuTag = Popen(["D:\ProxSpace-64\pm3\proxmark3\client\proxmark3.exe"],stdin=PIPE,stdout=PIPE,shell=True, stderr=PIPE)
while True:
    if emuTag.returncode != 0:
        print("ERROR")
        print(emuTag.returncode)
    time.sleep(1)
    #nnn = emuTag.stdout
    #print(nnn)
if emuTag.returncode != 0:
    print("ERROR")
    print(emuTag.returncode)
    print(emuTag.stderr.read())

#for line in emuTag.stdout.decode('utf-8'):
#    print("O=:", line)
#time.sleep(5)
print("out: %s" % emuTag.stdout.readline())
print("out: %s" % emuTag.stdout.readline())
print("out: %s" % emuTag.stdout.readline())
nnn = emuTag.stdout.read()
print(nnn)
if "[usb] pm3 -->" in nnn:
    print("OK")
    eemuTag.stdin.write('hf 14a\n')
    time.sleep(1)
    one_line_output = emuTag.stdout.readline()
    print(one_line_output)
    while True:
        time.sleep(1)
        nnn = emuTag.stdout
        print(nnn)
print("_______END_______")

