#include "common.h"
/* Generated file, do not edit */
#ifndef ON_DEVICE
#define SECTVERSINFO
#else
#define SECTVERSINFO __attribute__((section(".version_information")))
#endif

const struct version_information SECTVERSINFO version_information = {
    VERSION_INFORMATION_MAGIC,
    1,
    1,
    1,
    "RRG/Iceman/master/release (git)",
    "",
};
